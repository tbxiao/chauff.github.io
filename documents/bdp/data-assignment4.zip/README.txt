The Lahman Baseball Database

Salaries.csv

yearID         Year
teamID         Team
lgID           League
playerID       Player ID code
salary         Salary
2013 Version
Release Date: February 14, 2014

------------------------------------------------------------------------------

Batting.csv

playerID       Player ID code
yearID         Year
stint          player's stint (order of appearances within a season)
teamID         Team
lgID           League
G              Games
G_batting      Game as batter
AB             At Bats
R              Runs
H              Hits
2B             Doubles
3B             Triples
HR             Homeruns
RBI            Runs Batted In
SB             Stolen Bases
CS             Caught Stealing
BB             Base on Balls
SO             Strikeouts
IBB            Intentional walks
HBP            Hit by pitch
SH             Sacrifice hits
SF             Sacrifice flies
GIDP           Grounded into double plays